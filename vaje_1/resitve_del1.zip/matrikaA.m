function A=matrikaA(x,y)
% funkcija vrne matriko A, kjer A(i,j)=x(i)/y(j)
% ce je kateri element v y enak 0, ga postavimo na 1
% A=MatrikaA(x,y)
% x,y sta dana vrstici

if nargin==1
    y = x;
end

A=zeros(length(x),length(y));

for i=1:length(x)
    for j=1:length(y)
        if y(j)==0
            A(i,j)=1;
        else
            A(i,j)=x(i)/y(j);
        end
    end
end
end

