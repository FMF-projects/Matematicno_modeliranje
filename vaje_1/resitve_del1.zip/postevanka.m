function y=postevanka(a,m)
% funkcija izpise postevanko stevila a od a do m*a
% y=postevanka(a,m)
% y je vektor z elementi postevanke stevila a od a do m*a

y=a:a:m*a;

end
