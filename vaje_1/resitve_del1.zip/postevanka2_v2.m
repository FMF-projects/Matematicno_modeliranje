function A = postevanka2_v2(m,n)

a = 1:m;
b = 1:n;

A = zeros(m,n);

for j=1:n
    for i=1:m
        A(i,j) = a(i)*b(j);
    end
end