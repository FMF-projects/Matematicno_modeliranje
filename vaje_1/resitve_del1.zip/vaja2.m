% 2. naloga
n = 10;

A1 = triu(4*ones(n),1);
A2 = diag(1:n);
A3 = diag(1*ones(1,n-1),-1);
A4 = diag(-1*ones(1,n-2),-2);
A = A1+A2+A3+A4