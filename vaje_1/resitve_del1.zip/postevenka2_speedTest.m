% hitrost postevanka2

m = 10000;
n = 10000;

tic
postevanka2(m,n);
toc

tic
postevanka2_v2(m,n);
toc

tic
postevanka2_v3(m,n);
toc