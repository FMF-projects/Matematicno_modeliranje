function A = postevanka2(m,n)

a = 1:m;
b = 1:n;

A = zeros(m,n);

for i=1:m    
    for j=1:n
        A(i,j) = a(i)*b(j);
    end
end