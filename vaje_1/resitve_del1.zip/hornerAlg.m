function b = hornerAlg(a,x)

b = a(1);
n = size(a,2);
for i = 2:n
    b = x*b + a(i);
end
