function A = postevanka2_v3(m,n)

a = 1:m;
b = 1:n;

A = a.' .* b;


% podobna resitev
% [aa,bb] = ndgrid(a,b);
% A = aa.*bb;