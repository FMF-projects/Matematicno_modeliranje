function A = blocna_v2(n)

% blok T
diagLines = diag(ones(n-1,1),1) + diag(ones(n-1,1),-1);
T = -4*eye(n) + diagLines;

A = kron(eye(n),T) + kron(diagLines, eye(n));

end