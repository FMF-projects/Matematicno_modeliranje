function A = matrikaA_v2(x,y)
% funkcija vrne matriko A, kjer A(i,j)=x(i)/y(j)
% ce je kateri element v y enak 0, ga postavimo na 1
% A=MatrikaA(x,y)
% x,y sta dana vrstici

if nargin==1
    y = x;
end

A = x.' ./ y;
A(:,abs(y)<100*eps) = 1;



% podobna resitev
% [xx,yy] = ndgrid(x,y);
% A = xx./yy;
% A(abs(yy)<100*eps) = 1;
