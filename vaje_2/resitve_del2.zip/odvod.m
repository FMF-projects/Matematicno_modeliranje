function dp=odvod(p)
% ODVOD izracuna odvod polinoma
% dp=odvod(p)
% p je seznam koeficientov odvoda, p=[a_n,a_{n-1},...a_1,a_0]
% dp je seznam koeficientov odvoda
n=length(p)-1;
%preverimo ce je p konstanta
if n==0
    dp=0;
else   
    dp=[n:-1:1].*p(1:n);
end
end