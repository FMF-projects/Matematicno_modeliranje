a = 36;
A1 = [0 5];
A2 = [8 (2+ a/100)];

risi_brah(A1,A2)