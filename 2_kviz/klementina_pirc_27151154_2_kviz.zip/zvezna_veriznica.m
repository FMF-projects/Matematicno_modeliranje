b = 82;
l = 6;
T1 = [0 0];
T2 = [4 -3+b/100];
tol = 1e-10;

zvezna_ver(T1,T2,l,tol);

