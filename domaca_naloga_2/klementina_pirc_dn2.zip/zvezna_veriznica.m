b = 96;
l = 16;
T1 = [1 2];
T2 = [5+b/100 2];
tol = 1e-10;

zvezna_ver(T1,T2,l,tol);

